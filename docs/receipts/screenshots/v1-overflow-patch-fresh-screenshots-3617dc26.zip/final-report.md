# URAI AAA launch proof receipt

Generated: 2026-07-02T03:49:43.957Z
Repo: /home/adam/urai-spatial
Branch: main
Commit: 3617dc26e34094b2c31d3bd195901e8fcff38659
Base URL: https://urai.app
Receipt: /home/adam/urai-final-receipts/aaa-launch-proof-3617dc26-2026-07-02T03-49-36-078Z
Overall receipt status: GREEN

## Git state

Working tree has local changes:

```text
?? docs/AAA_FINAL_ASSET_AUDIT.md
?? docs/aaa-final-visual-contract-report.md
?? docs/receipts/V123_ASSET_WALL_AUDIT.latest.json
?? urai-tier1/public/assets/urai-aaa-full-pack/receipt-2026-07-01T03-04-52-007Z.md
```

## Command steps

| Step | Exit | Duration ms |
| --- | ---: | ---: |
| git-status | 0 | 86 |
| pnpm-install | 0 | 0 |
| pnpm-typecheck | 0 | 0 |
| pnpm-test-if-present | 0 | 0 |
| pnpm-build-static | 0 | 0 |
| firebase-deploy-static | 0 | 0 |

## Asset receipt

Result=GREEN; TOTAL_ASSETS=147; CORE_MISSING=0; EXPANSION_MISSING=0

## Route matrix summary

Routes checked: 18
Routes OK: 18
Routes needing review: 0
Fingerprint failures with HTTP 200: 0

All checked routes returned successful HTTP status and expected route fingerprints.

## Screenshots

Requested: yes
Captured: 0
Skipped/notes:
- Browser launch failed: browserType.launch: Executable doesn't exist at /home/adam/.cache/ms-playwright/chromium_headless_shell-1223/chrome-headless-shell-linux64/chrome-headless-shell
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝

## Quest / WebXR proof state

XR preview may be live if `/spatial/ar-vr` is green. Physical Quest 2 proof is NOT complete from this script. Record actual Quest Browser proof separately.

## Foundation DNS state

Complete: no
GitHub Pages apex A records: no
HTTPS works: no

## Remaining honest gates

- Capture/review desktop and mobile screenshots if not already captured.
- Do not claim Quest 2 proof until actual Quest Browser testing is recorded.
- Do not claim `uraifoundation.org` DNS complete unless this receipt says DNS/HTTPS complete and manual browser verification agrees.
- Do not claim bespoke final art while core art remains placeholder-final.
- Do not claim production backend/provider automation until real auth/data/actions are wired and tested.
