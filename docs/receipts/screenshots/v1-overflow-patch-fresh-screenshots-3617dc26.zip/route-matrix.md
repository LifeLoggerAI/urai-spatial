# URAI live route matrix

Base: https://urai.app

| Route | HTTP | HTTP OK | Fingerprint OK | Overall | Final URL | ms | Missing required | Forbidden present | Title |
| --- | ---: | --- | --- | --- | --- | ---: | --- | --- | --- |
| / | 200 | yes | yes | yes | https://urai.app/ | 387 |  |  | URAI Spatial |
| /home | 200 | yes | yes | yes | https://urai.app/home/ | 281 |  |  | URAI Spatial |
| /ground | 200 | yes | yes | yes | https://urai.app/ground/ | 881 |  |  | URAI Ground World |
| /life-map | 200 | yes | yes | yes | https://urai.app/life-map/ | 485 |  |  | URAI Life Map |
| /focus | 200 | yes | yes | yes | https://urai.app/focus/ | 231 |  |  | URAI Spatial |
| /replay | 200 | yes | yes | yes | https://urai.app/replay/ | 253 |  |  | URAI Spatial |
| /mirror | 200 | yes | yes | yes | https://urai.app/mirror/ | 232 |  |  | URAI Spatial |
| /passport | 200 | yes | yes | yes | https://urai.app/passport/ | 357 |  |  | URAI Spatial |
| /status | 200 | yes | yes | yes | https://urai.app/status/ | 211 |  |  | URAI Status |
| /privacy-controls | 200 | yes | yes | yes | https://urai.app/privacy-controls/ | 431 |  |  | URAI Privacy Controls |
| /location-map | 200 | yes | yes | yes | https://urai.app/location-map/ | 378 |  |  | URAI Spatial |
| /spatial/ar-vr | 200 | yes | yes | yes | https://urai.app/spatial/ar-vr/ | 224 |  |  | URAI XR Portal |
| /demo | 200 | yes | yes | yes | https://urai.app/demo/ | 200 |  |  | URAI Spatial Demo |
| /demo/replay-film | 200 | yes | yes | yes | https://urai.app/demo/replay-film/ | 174 |  |  | URAI Spatial |
| /asset-audit | 200 | yes | yes | yes | https://urai.app/asset-audit/ | 718 |  |  | URAI Asset Audit |
| /tier3 | 200 | yes | yes | yes | https://urai.app/tier3 | 81 |  |  | URAI Spatial |
| /tier4 | 200 | yes | yes | yes | https://urai.app/tier4/ | 190 |  |  | URAI Spatial Tier 4 |
| /tier5 | 200 | yes | yes | yes | https://urai.app/tier5/ | 927 |  |  | URAI Spatial Tier 5 |
