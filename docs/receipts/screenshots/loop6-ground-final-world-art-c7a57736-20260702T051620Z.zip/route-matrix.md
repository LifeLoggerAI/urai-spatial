# URAI live route matrix

Base: https://urai.app

| Route | HTTP | HTTP OK | Fingerprint OK | Overall | Final URL | ms | Missing required | Forbidden present | Title |
| --- | ---: | --- | --- | --- | --- | ---: | --- | --- | --- |
| / | 200 | yes | yes | yes | https://urai.app/ | 329 |  |  | URAI Spatial |
| /home | 200 | yes | yes | yes | https://urai.app/home/ | 330 |  |  | URAI Spatial |
| /ground | 200 | yes | yes | yes | https://urai.app/ground/ | 251 |  |  | URAI Ground World |
| /life-map | 200 | yes | yes | yes | https://urai.app/life-map/ | 209 |  |  | URAI Life Map |
| /focus | 200 | yes | yes | yes | https://urai.app/focus/ | 304 |  |  | URAI Spatial |
| /replay | 200 | yes | yes | yes | https://urai.app/replay/ | 312 |  |  | URAI Spatial |
| /mirror | 200 | yes | yes | yes | https://urai.app/mirror/ | 221 |  |  | URAI Spatial |
| /passport | 200 | yes | yes | yes | https://urai.app/passport/ | 334 |  |  | URAI Spatial |
| /status | 200 | yes | yes | yes | https://urai.app/status/ | 232 |  |  | URAI Status |
| /privacy-controls | 200 | yes | yes | yes | https://urai.app/privacy-controls/ | 249 |  |  | URAI Privacy Controls |
| /location-map | 200 | yes | yes | yes | https://urai.app/location-map/ | 276 |  |  | URAI Spatial |
| /spatial/ar-vr | 200 | yes | yes | yes | https://urai.app/spatial/ar-vr/ | 179 |  |  | URAI XR Portal |
| /demo | 200 | yes | yes | yes | https://urai.app/demo/ | 333 |  |  | URAI Spatial Demo |
| /demo/replay-film | 200 | yes | yes | yes | https://urai.app/demo/replay-film/ | 256 |  |  | URAI Spatial |
| /asset-audit | 200 | yes | yes | yes | https://urai.app/asset-audit/ | 181 |  |  | URAI Asset Audit |
| /tier3 | 200 | yes | yes | yes | https://urai.app/tier3 | 230 |  |  | URAI Spatial |
| /tier4 | 200 | yes | yes | yes | https://urai.app/tier4/ | 237 |  |  | URAI Spatial Tier 4 |
| /tier5 | 200 | yes | yes | yes | https://urai.app/tier5/ | 249 |  |  | URAI Spatial Tier 5 |
