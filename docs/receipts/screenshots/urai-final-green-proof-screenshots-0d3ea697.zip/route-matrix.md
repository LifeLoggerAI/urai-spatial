# URAI live route matrix

Base: https://urai.app

| Route | HTTP | HTTP OK | Fingerprint OK | Overall | Final URL | ms | Missing required | Forbidden present | Title |
| --- | ---: | --- | --- | --- | --- | ---: | --- | --- | --- |
| / | 200 | yes | yes | yes | https://urai.app/ | 258 |  |  | URAI Spatial |
| /home | 200 | yes | yes | yes | https://urai.app/home/ | 224 |  |  | URAI Spatial |
| /ground | 200 | yes | yes | yes | https://urai.app/ground/ | 274 |  |  | URAI Ground World |
| /life-map | 200 | yes | yes | yes | https://urai.app/life-map/ | 357 |  |  | URAI Life Map |
| /focus | 200 | yes | yes | yes | https://urai.app/focus/ | 773 |  |  | URAI Spatial |
| /replay | 200 | yes | yes | yes | https://urai.app/replay/ | 199 |  |  | URAI Spatial |
| /mirror | 200 | yes | yes | yes | https://urai.app/mirror/ | 293 |  |  | URAI Spatial |
| /passport | 200 | yes | yes | yes | https://urai.app/passport/ | 151 |  |  | URAI Spatial |
| /status | 200 | yes | yes | yes | https://urai.app/status/ | 324 |  |  | URAI Status |
| /privacy-controls | 200 | yes | yes | yes | https://urai.app/privacy-controls/ | 203 |  |  | URAI Privacy Controls |
| /location-map | 200 | yes | yes | yes | https://urai.app/location-map/ | 185 |  |  | URAI Spatial |
| /spatial/ar-vr | 200 | yes | yes | yes | https://urai.app/spatial/ar-vr/ | 187 |  |  | URAI XR Portal |
| /demo | 200 | yes | yes | yes | https://urai.app/demo/ | 209 |  |  | URAI Spatial Demo |
| /demo/replay-film | 200 | yes | yes | yes | https://urai.app/demo/replay-film/ | 177 |  |  | URAI Spatial |
| /asset-audit | 200 | yes | yes | yes | https://urai.app/asset-audit/ | 123 |  |  | URAI Asset Audit |
| /tier3 | 200 | yes | yes | yes | https://urai.app/tier3 | 134 |  |  | URAI Spatial |
| /tier4 | 200 | yes | yes | yes | https://urai.app/tier4/ | 652 |  |  | URAI Spatial Tier 4 |
| /tier5 | 200 | yes | yes | yes | https://urai.app/tier5/ | 328 |  |  | URAI Spatial Tier 5 |
