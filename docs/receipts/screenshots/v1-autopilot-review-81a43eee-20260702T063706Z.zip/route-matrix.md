# URAI live route matrix

Base: https://urai.app

| Route | HTTP | HTTP OK | Fingerprint OK | Overall | Final URL | ms | Missing required | Forbidden present | Title |
| --- | ---: | --- | --- | --- | --- | ---: | --- | --- | --- |
| / | 200 | yes | yes | yes | https://urai.app/ | 326 |  |  | URAI Spatial |
| /home | 200 | yes | yes | yes | https://urai.app/home/ | 251 |  |  | URAI Spatial |
| /ground | 200 | yes | no | no | https://urai.app/ground/ | 228 | walkable-first-person-ground-layer |  | URAI Spatial |
| /life-map | 200 | yes | yes | yes | https://urai.app/life-map/ | 256 |  |  | URAI Life Map |
| /focus | 200 | yes | yes | yes | https://urai.app/focus/ | 307 |  |  | URAI Spatial |
| /replay | 200 | yes | yes | yes | https://urai.app/replay/ | 325 |  |  | URAI Spatial |
| /mirror | 200 | yes | yes | yes | https://urai.app/mirror/ | 280 |  |  | URAI Spatial |
| /passport | 200 | yes | yes | yes | https://urai.app/passport/ | 217 |  |  | URAI Spatial |
| /status | 200 | yes | yes | yes | https://urai.app/status/ | 732 |  |  | URAI Status |
| /privacy-controls | 200 | yes | yes | yes | https://urai.app/privacy-controls/ | 292 |  |  | URAI Privacy Controls |
| /location-map | 200 | yes | yes | yes | https://urai.app/location-map/ | 232 |  |  | URAI Spatial |
| /spatial/ar-vr | 200 | yes | yes | yes | https://urai.app/spatial/ar-vr/ | 464 |  |  | URAI XR Portal |
| /demo | 200 | yes | yes | yes | https://urai.app/demo/ | 228 |  |  | URAI Spatial Demo |
| /demo/replay-film | 200 | yes | yes | yes | https://urai.app/demo/replay-film/ | 297 |  |  | URAI Spatial |
| /asset-audit | 200 | yes | yes | yes | https://urai.app/asset-audit/ | 191 |  |  | URAI Asset Audit |
| /tier3 | 200 | yes | yes | yes | https://urai.app/tier3 | 221 |  |  | URAI Spatial |
| /tier4 | 200 | yes | yes | yes | https://urai.app/tier4/ | 195 |  |  | URAI Spatial Tier 4 |
| /tier5 | 200 | yes | yes | yes | https://urai.app/tier5/ | 281 |  |  | URAI Spatial Tier 5 |
