# URAI AAA launch proof receipt

Generated: 2026-07-02T05:32:56.442Z
Repo: /home/adam/urai-spatial
Branch: main
Commit: 5c741a7a23c0a4c7800677a7ed60b40002bba10b
Base URL: https://urai.app
Receipt: /home/adam/urai-final-receipts/aaa-launch-proof-5c741a7a-2026-07-02T05-31-43-965Z
Overall receipt status: YELLOW_OR_RED_REVIEW_REQUIRED

## Git state

Working tree has local changes:

```text
?? docs/receipts/V123_ASSET_WALL_AUDIT.latest.json
```

## Command steps

| Step | Exit | Duration ms |
| --- | ---: | ---: |
| git-status | 0 | 89 |
| pnpm-install | 0 | 0 |
| pnpm-typecheck | 0 | 0 |
| pnpm-test-if-present | 0 | 0 |
| pnpm-build-static | 0 | 0 |
| firebase-deploy-static | 0 | 0 |

## Asset receipt

Result=GREEN; TOTAL_ASSETS=147; CORE_MISSING=0; EXPANSION_MISSING=0

## Route matrix summary

Routes checked: 18
Routes OK: 17
Routes needing review: 1
Fingerprint failures with HTTP 200: 1

- /ground: HTTP=200; fingerprint=fail; missing=walkable-first-person-ground-layer; forbidden=none; error=none

## Screenshots

Requested: yes
Captured: 24
No screenshot notes.

## Quest / WebXR proof state

XR preview may be live if `/spatial/ar-vr` is green. Physical Quest 2 proof is NOT complete from this script. Record actual Quest Browser proof separately.

## Foundation DNS state

Complete: no
GitHub Pages apex A records: no
HTTPS works: no

## Remaining honest gates

- Capture/review desktop and mobile screenshots if not already captured.
- Do not claim Quest 2 proof until actual Quest Browser testing is recorded.
- Do not claim `uraifoundation.org` DNS complete unless this receipt says DNS/HTTPS complete and manual browser verification agrees.
- Do not claim bespoke final art while core art remains placeholder-final.
- Do not claim production backend/provider automation until real auth/data/actions are wired and tested.
