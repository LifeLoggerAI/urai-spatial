# URAI live route matrix

Base: https://urai.app

| Route | HTTP | HTTP OK | Fingerprint OK | Overall | Final URL | ms | Missing required | Forbidden present | Title |
| --- | ---: | --- | --- | --- | --- | ---: | --- | --- | --- |
| / | 200 | yes | yes | yes | https://urai.app/ | 313 |  |  | URAI Spatial |
| /home | 200 | yes | yes | yes | https://urai.app/home/ | 285 |  |  | URAI Spatial |
| /ground | 200 | yes | yes | yes | https://urai.app/ground/ | 256 |  |  | URAI Ground World |
| /life-map | 200 | yes | yes | yes | https://urai.app/life-map/ | 229 |  |  | URAI Life Map |
| /focus | 200 | yes | yes | yes | https://urai.app/focus/ | 281 |  |  | URAI Spatial |
| /replay | 200 | yes | yes | yes | https://urai.app/replay/ | 178 |  |  | URAI Spatial |
| /mirror | 200 | yes | yes | yes | https://urai.app/mirror/ | 208 |  |  | URAI Spatial |
| /passport | 200 | yes | yes | yes | https://urai.app/passport/ | 222 |  |  | URAI Spatial |
| /status | 200 | yes | yes | yes | https://urai.app/status/ | 246 |  |  | URAI Status |
| /privacy-controls | 200 | yes | yes | yes | https://urai.app/privacy-controls/ | 252 |  |  | URAI Privacy Controls |
| /location-map | 200 | yes | yes | yes | https://urai.app/location-map/ | 297 |  |  | URAI Spatial |
| /spatial/ar-vr | 200 | yes | yes | yes | https://urai.app/spatial/ar-vr/ | 495 |  |  | URAI XR Portal |
| /demo | 200 | yes | yes | yes | https://urai.app/demo/ | 247 |  |  | URAI Spatial Demo |
| /demo/replay-film | 200 | yes | yes | yes | https://urai.app/demo/replay-film/ | 243 |  |  | URAI Spatial |
| /asset-audit | 200 | yes | yes | yes | https://urai.app/asset-audit/ | 1341 |  |  | URAI Asset Audit |
| /tier3 | 200 | yes | yes | yes | https://urai.app/tier3 | 191 |  |  | URAI Spatial |
| /tier4 | 200 | yes | yes | yes | https://urai.app/tier4/ | 258 |  |  | URAI Spatial Tier 4 |
| /tier5 | 200 | yes | yes | yes | https://urai.app/tier5/ | 336 |  |  | URAI Spatial Tier 5 |
